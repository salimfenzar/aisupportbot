import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export default async function handler(req, res) {
  // ✅ CORS Headers
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }

  if (req.method !== "POST") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  const { naam, functie, ervaring, taken, vaardigheden, opleiding, sector } = req.body;

  const prompt = `Je bent een AI-loopbaanadviseur. Analyseer dit profiel:
Naam: ${naam}
Functie: ${functie}
Ervaring: ${ervaring} jaar
Taken: ${taken}
Vaardigheden: ${vaardigheden}
Opleidingsniveau: ${opleiding}
Sector: ${sector}

Geef:
1. Een AI-risicoscore van 0-100
2. Een korte uitleg waarom
3. Eén suggestie om futureproof te blijven
Gebruik maximaal 100 woorden.`;

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4-1106-preview", // ✅ GPT-4.1 model
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7,
    });

    const output = completion.choices?.[0]?.message?.content || "Geen resultaat ontvangen.";
    res.status(200).json({ resultaat: output });
  } catch (error) {
    console.error("OpenAI fout:", error);
    res.status(500).json({ error: "Fout bij het ophalen van AI-analyse." });
  }
}
